const state = { config: null, runningWindows: [], selectedRunning: null, confirmAction: null };
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const TRANSLATIONS = {
  en: {
    add_window: 'Add window', saved_windows: 'Saved windows', saved_subtitle: 'Select an icon to capture the current position.',
    sync_windows: 'Synchronize windows', synchronizing: 'Synchronizing...', search_windows: 'Search windows...',
    cancel: 'Cancel', no_saved: 'No saved windows', add_windows_hint: 'Add the windows you want to move.',
    loading: 'Loading...', no_windows: 'No windows found', title: 'Title', process: 'Process', position: 'Position', size: 'Size', checking: 'Checking...',
    running: 'Running', missing: 'Not running', capture: 'Capture current position', delete: 'Delete window', delete_question: 'Delete',
    delete_text: 'The window will be removed from the saved list.', application: 'Application', settings: 'Settings', settings_title: 'WindowFlow settings',
    settings_description: 'Control startup and global shortcut behavior.', startup_sync: 'Synchronize on WindowFlow startup',
    startup_sync_hint: 'Apply saved positions when WindowFlow opens.', app_sync: 'Synchronize when saved apps start',
    app_sync_hint: 'Move an app as soon as it appears after launch.', language: 'Language', shortcut: 'Global shortcut',
    shortcut_hint: 'Click the field and press your key combination. It saves automatically.', shortcut_press: 'Press Ctrl, Alt, Shift or Win with another key...',
    shortcut_saved: 'Shortcut saved automatically.', shortcut_error: 'Could not save shortcut.', send_tray: 'Send to tray', made_by: 'Made by',
    icon_unavailable: 'Application icon unavailable', loading_icon: 'Loading application icon...'
  },
  ru: {
    add_window: 'Добавить окно', saved_windows: 'Сохранённые окна', saved_subtitle: 'Нажмите на иконку, чтобы запомнить позицию.',
    sync_windows: 'Синхронизировать окна', synchronizing: 'Синхронизация...', search_windows: 'Поиск окон...',
    cancel: 'Отмена', no_saved: 'Нет сохранённых окон', add_windows_hint: 'Добавьте окна, которые нужно перемещать.',
    loading: 'Загрузка...', no_windows: 'Окна не найдены', title: 'Заголовок', process: 'Процесс', position: 'Позиция', size: 'Размер', checking: 'Проверка...',
    running: 'Запущено', missing: 'Не запущено', capture: 'Запомнить текущую позицию', delete: 'Удалить окно', delete_question: 'Удалить',
    delete_text: 'Окно будет удалено из сохранённого списка.', application: 'Приложение', settings: 'Настройки', settings_title: 'Настройки WindowFlow',
    settings_description: 'Управление запуском и глобальной комбинацией клавиш.', startup_sync: 'Синхронизировать при запуске WindowFlow',
    startup_sync_hint: 'Применять сохранённые позиции при открытии WindowFlow.', app_sync: 'Синхронизировать при запуске сохранённых приложений',
    app_sync_hint: 'Перемещать приложение сразу после его запуска.', language: 'Язык', shortcut: 'Глобальная комбинация клавиш',
    shortcut_hint: 'Нажмите на поле и нажмите нужную комбинацию. Она сохранится автоматически.', shortcut_press: 'Нажмите Ctrl, Alt, Shift или Win вместе с другой клавишей...',
    shortcut_saved: 'Комбинация сохранена автоматически.', shortcut_error: 'Не удалось сохранить комбинацию.', send_tray: 'Свернуть в трей', made_by: 'Создано',
    icon_unavailable: 'Иконка приложения недоступна', loading_icon: 'Загрузка иконки приложения...'
  }
};

function currentLanguage() { return state.config?.language === 'ru' ? 'ru' : 'en'; }
function t(key) { return TRANSLATIONS[currentLanguage()][key] || TRANSLATIONS.en[key] || key; }

function ensureLanguageSelector() {
  if ($('#languageSelect')) return;
  const head = $('#settingsModal .modal-head');
  head.insertAdjacentHTML('afterend', '<label class="language-field" id="languageField"><span class="language-caption"><span class="language-symbol">◎</span><span id="languageLabel">Language</span></span><select id="languageSelect"><option value="en">English</option><option value="ru">Русский</option></select></label>');
}

function applyTranslations() {
  document.documentElement.lang = currentLanguage();
  $('.list-head h1').textContent = t('saved_windows');
  $('.list-head p').textContent = t('saved_subtitle');
  $('#addWindowButton').innerHTML = `<span>＋</span> ${t('add_window')}`;
  $('#settingsButton').title = t('settings'); $('#settingsButton').setAttribute('aria-label', t('settings'));
  $('#trayButton').title = t('send_tray'); $('#trayButton').setAttribute('aria-label', t('send_tray'));
  $('#syncLayoutButton').innerHTML = `<span>↔</span> ${t('sync_windows')}`;
  $('#windowModal .eyebrow').textContent = t('add_window').toUpperCase();
  $('#windowModal h2').textContent = t('add_window');
  $('#windowSearch').placeholder = t('search_windows');
  $('#windowModal .preview-empty').innerHTML = '';
  $('#windowModal [data-close="windowModal"]').textContent = t('cancel'); $('#confirmAddWindow').textContent = t('add_window');
  $('#confirmTitle').textContent = `${t('delete_question')} “Window”?`; $('#confirmText').textContent = t('delete_text');
  $('#cancelConfirm').textContent = t('cancel'); $('#confirmAction').textContent = t('delete');
  $('#settingsModal .eyebrow').textContent = t('settings').toUpperCase(); $('#settingsModal h2').textContent = t('settings_title');
  $('#settingsModal .modal-head p').textContent = t('settings_description');
  $('#languageLabel').textContent = t('language'); $('#languageSelect').value = currentLanguage();
  $('#applyStartupSetting').closest('.setting-row').querySelector('b').textContent = t('startup_sync');
  $('#applyStartupSetting').closest('.setting-row').querySelector('small').textContent = t('startup_sync_hint');
  $('#autoApplySetting').closest('.setting-row').querySelector('b').textContent = t('app_sync');
  $('#autoApplySetting').closest('.setting-row').querySelector('small').textContent = t('app_sync_hint');
  $('.hotkey-field').firstChild.textContent = t('shortcut'); $('#hotkeyHint').textContent = t('shortcut_hint');
  $('.watermark').innerHTML = `${t('made_by')} <a href="https://t.me/owleo" title="t.me/owleo">t.me/owleo</a><span>|</span><a href="https://github.com/Thebaltusss" title="github.com/Thebaltusss">github.com/Thebaltusss</a>`;
}

async function api(url, options = {}) {
  const response = await fetch(url, { headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, ...options });
  const body = await response.json().catch(() => ({ ok: false, error: 'Invalid server response' }));
  if (!response.ok || body.ok === false) throw new Error(body.error || `Request failed: ${response.status}`);
  return body;
}

function escapeHtml(value) { const node = document.createElement('div'); node.textContent = value ?? ''; return node.innerHTML; }
function initials(name) { return (name || 'Window').split(/\s+/).slice(0, 2).map((part) => part[0]).join('').toUpperCase(); }
function windows() { return state.config?.layouts?.[state.config.active_layout]?.windows || []; }
function openModal(id) { $(`#${id}`).classList.add('open'); }
function closeModal(id) { $(`#${id}`).classList.remove('open'); }
function showError(error) { console.error(error); }

async function refreshAll() {
  try {
    const result = await api('/api/layouts'); state.config = result.data; applyTranslations(); renderWindows(); await refreshStatus();
  } catch (error) { showError(error); }
}

async function refreshStatus() {
  const result = await api('/api/status');
  const statusById = Object.fromEntries((result.data.windows || []).map((item) => [item.id, item]));
  $$('.window-card').forEach((card) => {
    const status = statusById[card.dataset.id]; if (!status) return;
    const badge = card.querySelector('.status-badge'); badge.className = `status-badge ${status.status === 'missing' ? 'missing' : ''}`;
    badge.innerHTML = `<i></i>${status.status === 'running' ? t('running') : t('missing')}`;
  });
}

async function loadSavedIcon(container, id) {
  try {
    const result = await api(`/api/windows/${id}/icon`);
    container.innerHTML = `<img src="${result.data.image}" alt="Application icon">`;
  } catch (_) {
    // Keep the initials placeholder when the executable icon is unavailable.
  }
}

function renderWindows() {
  const saved = windows(); $('#windowCount').textContent = saved.length;
  const list = $('#windowsList');
  if (!saved.length) {
    list.innerHTML = `<div class="empty-state"><div class="empty-icon">▣</div><h3>${t('no_saved')}</h3><p>${t('add_windows_hint')}</p><button class="button primary" id="emptyAddButton">＋ ${t('add_window')}</button></div>`;
    $('#emptyAddButton').addEventListener('click', openAddWindow); return;
  }
  list.innerHTML = saved.map((item) => `<article class="window-card" data-id="${item.id}"><div class="window-logo"><span>${escapeHtml(initials(item.display_name))}</span></div><div class="window-info"><div class="window-title" title="${escapeHtml(item.display_name)}">${escapeHtml(item.display_name)}</div><div class="window-process">${escapeHtml(item.process_name || item.executable || t('application'))}</div><div class="status-badge"><i></i>${t('checking')}</div></div><div class="window-position"><div><b>X</b> ${Number(item.x) || 0} &nbsp; <b>Y</b> ${Number(item.y) || 0}</div><div><b>${t('size')}</b> ${Number(item.width) || 0}×${Number(item.height) || 0}</div></div><button class="capture-button" data-action="capture" title="${t('capture')}" aria-label="${t('capture')}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h6M4 4v6M20 20h-6M20 20v-6M9 15l6-6M15 15l-6-6"/></svg></button><button class="delete-button" data-action="delete" title="${t('delete')}" aria-label="${t('delete')}">×</button></article>`).join('');
  $$('.window-card').forEach((card) => { card.addEventListener('click', handleWindowAction); loadSavedIcon(card.querySelector('.window-logo'), card.dataset.id); });
}

async function handleWindowAction(event) {
  const action = event.target.closest('[data-action]')?.dataset.action; if (!action) return;
  const id = event.currentTarget.dataset.id; const item = windows().find((window) => window.id === id);
  try {
    if (action === 'capture') { await api(`/api/windows/${id}/capture`, { method: 'POST' }); await refreshAll(); }
    if (action === 'delete') askConfirm(`${t('delete_question')} “${item.display_name}”?`, t('delete_text'), async () => { await api(`/api/windows/${id}`, { method: 'DELETE' }); await refreshAll(); });
  } catch (error) { showError(error); }
}

function openAddWindow() {
  state.selectedRunning = null; $('#windowSearch').value = ''; $('#confirmAddWindow').disabled = true; $('#runningWindowList').innerHTML = `<div class="empty-state">${t('loading')}</div>`; $('#selectedWindowDetail').innerHTML = ''; $('#windowPreview').removeAttribute('src'); $('.preview-empty').classList.add('hidden'); openModal('windowModal');
  api('/api/windows').then((result) => { state.runningWindows = result.data || []; renderRunningWindows(); }).catch(showError);
}

async function loadWindowIcon(hwnd) {
  const image = $('#windowPreview'); const empty = $('.preview-empty'); image.removeAttribute('src'); empty.textContent = t('loading_icon'); empty.classList.remove('hidden');
  try { const result = await api(`/api/windows/icon/by-hwnd/${hwnd}`); image.src = result.data.image; empty.classList.add('hidden'); } catch (error) { empty.textContent = t('icon_unavailable'); showError(error); }
}

function renderRunningWindows() {
  const query = $('#windowSearch').value.trim().toLowerCase();
  const found = state.runningWindows.filter((item) => `${item.title} ${item.process_name} ${item.executable}`.toLowerCase().includes(query));
  $('#runningWindowList').innerHTML = found.length ? found.map((item) => `<div class="running-row ${state.selectedRunning?.hwnd === item.hwnd ? 'selected' : ''}" data-hwnd="${item.hwnd}"><div class="row-icon"><span>${escapeHtml(initials(item.process_name || item.title))}</span></div><div class="row-info"><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.process_name || item.executable || t('application'))}</small></div></div>`).join('') : `<div class="empty-state" style="padding:55px 10px">${t('no_windows')}</div>`;
  $$('.running-row').forEach((row) => { loadWindowIconInto(row.querySelector('.row-icon'), row.dataset.hwnd); row.addEventListener('click', () => { state.selectedRunning = state.runningWindows.find((item) => String(item.hwnd) === row.dataset.hwnd); renderRunningWindows(); loadWindowIcon(row.dataset.hwnd); }); });
  $('#confirmAddWindow').disabled = !state.selectedRunning;
  $('#selectedWindowDetail').innerHTML = state.selectedRunning ? `<div class="detail-grid"><span><b>${t('title')}</b>${escapeHtml(state.selectedRunning.title)}</span><span><b>${t('process')}</b>${escapeHtml(state.selectedRunning.process_name || '—')}</span><span><b>${t('position')}</b>${state.selectedRunning.x}, ${state.selectedRunning.y} · ${state.selectedRunning.width}×${state.selectedRunning.height}</span></div>` : '';
}

async function loadWindowIconInto(container, hwnd) {
  try {
    const result = await api(`/api/windows/icon/by-hwnd/${hwnd}`);
    container.innerHTML = `<img src="${result.data.image}" alt="Application icon">`;
  } catch (_) {
    // Keep the initials fallback when Windows cannot provide an icon.
  }
}

function askConfirm(title, text, action) { $('#confirmTitle').textContent = title; $('#confirmText').textContent = text; state.confirmAction = action; openModal('confirmModal'); }

function shortcutFromEvent(event) {
  const parts = [];
  if (event.ctrlKey) parts.push('Ctrl');
  if (event.altKey) parts.push('Alt');
  if (event.shiftKey) parts.push('Shift');
  if (event.metaKey) parts.push('Win');
  const modifierOnly = ['Control', 'Alt', 'Shift', 'Meta', 'OS'];
  if (modifierOnly.includes(event.key)) return '';
  let key = event.key;
  if (key === ' ') key = 'Space';
  if (key.startsWith('Arrow')) key = key.slice(5);
  if (key.length === 1) key = key.toUpperCase();
  if (key) parts.push(key);
  return parts.length > 1 ? parts.join('+') : '';
}

async function saveShortcut(shortcut) {
  await api('/api/settings', { method: 'POST', body: JSON.stringify({ hotkey: shortcut }) });
  $('#hotkeyHint').textContent = t('shortcut_saved');
}

document.addEventListener('DOMContentLoaded', () => {
  ensureLanguageSelector(); refreshAll(); setInterval(() => refreshStatus().catch(() => {}), 2500);
  $('#addWindowButton').addEventListener('click', openAddWindow); $('#windowSearch').addEventListener('input', renderRunningWindows);
  $('#settingsButton').addEventListener('click', async () => { try { const result = await api('/api/layouts'); const settings = result.data; state.config = settings; applyTranslations(); $('#applyStartupSetting').checked = !!settings.apply_on_startup; $('#autoApplySetting').checked = !!settings.auto_apply_windows; $('#hotkeyInput').value = settings.hotkey || 'Ctrl+Alt+W'; $('#languageSelect').value = settings.language || 'en'; openModal('settingsModal'); } catch (error) { showError(error); } });
  $('#applyStartupSetting').addEventListener('change', () => api('/api/settings', { method: 'POST', body: JSON.stringify({ apply_on_startup: $('#applyStartupSetting').checked }) }).catch(showError));
  $('#autoApplySetting').addEventListener('change', () => api('/api/settings', { method: 'POST', body: JSON.stringify({ auto_apply_windows: $('#autoApplySetting').checked }) }).catch(showError));
  $('#languageSelect').addEventListener('change', async () => { try { const result = await api('/api/settings', { method: 'POST', body: JSON.stringify({ language: $('#languageSelect').value }) }); state.config = result.data; applyTranslations(); renderWindows(); await refreshStatus(); } catch (error) { showError(error); } });
  $('#trayButton').addEventListener('click', async () => { try { await api('/api/tray/hide', { method: 'POST' }); } catch (error) { showError(error); } });
  $('#hotkeyInput').addEventListener('focus', () => { $('#hotkeyInput').classList.add('recording'); $('#hotkeyHint').textContent = t('shortcut_press'); });
  $('#hotkeyInput').addEventListener('keydown', async (event) => { const shortcut = shortcutFromEvent(event); if (!shortcut) return; event.preventDefault(); $('#hotkeyInput').value = shortcut; $('#hotkeyInput').classList.remove('recording'); try { await saveShortcut(shortcut); } catch (error) { $('#hotkeyHint').textContent = t('shortcut_error'); showError(error); } });
  $('#hotkeyInput').addEventListener('blur', () => { $('#hotkeyInput').classList.remove('recording'); });
  $('#confirmAddWindow').addEventListener('click', async () => { if (!state.selectedRunning) return; try { await api('/api/windows/add', { method: 'POST', body: JSON.stringify({ hwnd: state.selectedRunning.hwnd }) }); closeModal('windowModal'); await refreshAll(); } catch (error) { showError(error); } });
  $('#syncLayoutButton').addEventListener('click', async () => { const button = $('#syncLayoutButton'); button.disabled = true; button.innerHTML = `<span>↻</span> ${t('synchronizing')}`; try { await api('/api/layout/apply', { method: 'POST' }); await refreshStatus(); } catch (error) { showError(error); } finally { button.disabled = false; button.innerHTML = `<span>↔</span> ${t('sync_windows')}`; } });
  $$('[data-close]').forEach((button) => button.addEventListener('click', () => closeModal(button.dataset.close)));
  $('#confirmAction').addEventListener('click', async () => { const action = state.confirmAction; state.confirmAction = null; closeModal('confirmModal'); if (action) { try { await action(); } catch (error) { showError(error); } } }); $('#cancelConfirm').addEventListener('click', () => { state.confirmAction = null; closeModal('confirmModal'); });
});
